Cześć, tu nquantum, witaj w Novoline

Novoline jest wirusem ransomware połączonym z writerem oraz ma w sobie kilka GDI payloadów (jak memz).
Za żadne szkody nie odpowiadam, wirusa odpalasz na własną odpowiedzialność i najlepiej robić to na środowisku wirtualnym, takim jak QEMU (https://qemu.org) czy VMWare (https://www.vmware.com/).

Wrzuć plik DLL oraz EXE na pulpit i odpal plik "Novoline.exe" jako admininistrator.

Następnie czekaj na efekt :)

Po upływie kilkunastu sekund, zrestartuj środowisko wirtualne.